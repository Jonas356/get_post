# 🛒 Aplicación de Carrito de Compras con Flask

## Descripción
Aplicación web completa de carrito de compras desarrollada con Flask que simula una tienda en línea con funcionalidad de gestión de productos, carrito de compras y checkout.

## Características Implementadas

### 1. **Gestión de Productos**
- Base de datos simulada con 6 productos de electrónica
- Cada producto tiene: ID, nombre, precio, descripción e icono emoji
- Ruta `/productos` muestra todos los productos disponibles
- Interfaz atractiva con Bootstrap 5

### 2. **Carrito de Compras**
- Almacenamiento en sesiones de usuario
- Agregar productos al carrito con `GET /agregar/<producto_id>`
- Ver carrito completo en `/carrito`
- Actualizar cantidades de productos
- Eliminar productos individuales del carrito
- Limpiar todo el carrito

### 3. **Funcionalidades de Checkout**
- Ruta `/checkout` para procesar compras
- Formulario con información de envío:
  - Nombre completo
  - Correo electrónico
  - Dirección de envío
- Selección de método de pago (Tarjeta, PayPal, Transferencia)
- Página de confirmación post-compra

### 4. **Sistema de Notificaciones**
- Mensajes flash para confirmar acciones
- Alertas de éxito/error/información
- Feedback visual en la interfaz

## Estructura del Proyecto

```
Ejercicio 1/
├── app.py                    # Aplicación principal Flask
└── template/
    ├── base.html            # Template base con Bootstrap
    ├── index.html           # Página de inicio
    ├── productos.html       # Listado de productos
    ├── carrito.html         # Vista del carrito
    ├── checkout.html        # Formulario de checkout
    └── confirmacion.html    # Página de confirmación
```

## Rutas Disponibles

| Ruta | Método | Descripción |
|------|--------|-------------|
| `/` | GET | Página de inicio |
| `/productos` | GET | Listado de todos los productos |
| `/carrito` | GET | Ver carrito de compras |
| `/agregar/<id>` | GET | Agregar producto al carrito |
| `/eliminar/<id>` | GET | Eliminar producto del carrito |
| `/actualizar-cantidad/<id>/<cantidad>` | GET | Actualizar cantidad de producto |
| `/limpiar-carrito` | GET | Vaciar el carrito completamente |
| `/checkout` | GET, POST | Formulario y procesamiento de compra |

## Cómo Usar

### 1. **Iniciar la Aplicación**
```bash
python app.py
```
La aplicación estará disponible en `http://127.0.0.1:5000`

### 2. **Funcionamiento Típico**
1. Ir a la página de inicio
2. Hacer clic en "Ver Productos"
3. Agregar productos al carrito
4. Ver carrito para revisar compra
5. Proceder al checkout
6. Completar formulario de envío
7. Confirmar compra

## Productos Disponibles

| Imagen | Nombre | Precio |
|--------|--------|--------|
| 💻 | Laptop | $999.99 |
| 🖱️ | Mouse | $29.99 |
| ⌨️ | Teclado | $79.99 |
| 🖥️ | Monitor | $299.99 |
| 🎧 | Audífonos | $149.99 |
| 📷 | Webcam | $89.99 |

## Características Técnicas

### Backend
- Framework: Flask
- Almacenamiento: Sesiones de usuario
- Lenguaje: Python 3

### Frontend
- Framework CSS: Bootstrap 5
- Iconos: Unicode emojis
- Templating: Jinja2

### Seguridad
- Secret key configurada para sesiones
- Variables de sesión protegidas
- Validación de formularios

## Posibles Mejoras Futuras

1. Base de datos persistente (SQLite, PostgreSQL)
2. Sistema de autenticación de usuarios
3. Historial de compras
4. Integración con pasarelas de pago reales
5. Sistema de búsqueda y filtrado de productos
6. Carrito persistente (base de datos)
7. Sistema de reseñas y calificaciones
8. Código de descuento/cupones
9. Gestión de inventario
10. Panel de administrador

## Variables de Entorno

- `FLASK_ENV`: Configurado como desarrollo (debug=True)
- `SECRET_KEY`: Clave de sesión (cambiar en producción)

---

**Autor**: Laboratorio 4 - Ejercicio 1  
**Versión**: 1.0  
**Fecha**: 14 de abril de 2026
