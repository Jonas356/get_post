from flask import Flask, request, render_template, session, redirect, url_for, flash
import os

app = Flask(__name__, template_folder=os.path.join(os.path.dirname(__file__), 'template'))
app.secret_key = 'd41d8cd98f00b204e9800998ecf8427e'

# Base de datos simulada de productos
PRODUCTOS = [
    {'id': 1, 'nombre': 'Laptop', 'precio': 999, 'descripcion': 'Laptop de alto rendimiento', 'imagen': '💻'},
    {'id': 2, 'nombre': 'Mouse', 'precio': 29, 'descripcion': 'Mouse inalámbrico', 'imagen': '🖱️'},
    {'id': 3, 'nombre': 'Teclado', 'precio': 79, 'descripcion': 'Teclado mecánico RGB', 'imagen': '⌨️'},
    {'id': 4, 'nombre': 'Monitor', 'precio': 299, 'descripcion': 'Monitor 4K 27 pulgadas', 'imagen': '🖥️'},
    {'id': 5, 'nombre': 'Audífonos', 'precio': 149, 'descripcion': 'Audífonos inalámbricos con cancelación de ruido', 'imagen': '🎧'},
    {'id': 6, 'nombre': 'Webcam', 'precio': 89, 'descripcion': 'Webcam 1080p HD', 'imagen': '📷'},
]


def obtener_carrito():
    """Obtiene el carrito de la sesión o crea uno vacío"""
    if 'carrito' not in session:
        session['carrito'] = []
    return session['carrito']


def obtener_producto_por_id(producto_id):
    """Busca un producto por su ID"""
    for producto in PRODUCTOS:
        if producto['id'] == producto_id:
            return producto
    return None


@app.route('/')
def index():
    return render_template('index.html', mensaje='Bienvenido a la Tienda de Alex!')


@app.route('/productos')
def productos():
    """Muestra todos los productos disponibles"""
    return render_template('productos.html', productos=PRODUCTOS)


@app.route('/carrito')
def ver_carrito():
    """Muestra el carrito de compras"""
    carrito = obtener_carrito()
    total = 0
    detalles_carrito = []
    
    for item in carrito:
        producto = obtener_producto_por_id(item['id'])
        if producto:
            subtotal = producto['precio'] * item['cantidad']
            total += subtotal
            detalles_carrito.append({'producto': producto,'cantidad': item['cantidad'],'subtotal': subtotal})
    
    return render_template('carrito.html', carrito=detalles_carrito, total=total)


@app.route('/agregar/<int:producto_id>')
def agregar_al_carrito(producto_id):
    """Agrega un producto al carrito"""
    carrito = obtener_carrito()
    producto = obtener_producto_por_id(producto_id)
    
    if not producto:
        flash('Producto no encontrado', 'error')
        return redirect(url_for('productos'))
    
    # Buscar si el producto ya está en el carrito
    producto_en_carrito = False
    for item in carrito:
        if item['id'] == producto_id:
            item['cantidad'] += 1
            producto_en_carrito = True
            break
    
    # Si no está, agregarlo
    if not producto_en_carrito:
        carrito.append({'id': producto_id, 'cantidad': 1})
    
    session.modified = True
    flash(f'{producto["nombre"]} agregado al carrito', 'success')
    return redirect(url_for('productos'))


@app.route('/eliminar/<int:producto_id>')
def eliminar_del_carrito(producto_id):
    """Elimina un producto del carrito"""
    carrito = obtener_carrito()
    carrito[:] = [item for item in carrito if item['id'] != producto_id]
    session.modified = True
    flash('Producto eliminado del carrito', 'success')
    return redirect(url_for('ver_carrito'))


@app.route('/actualizar-cantidad/<int:producto_id>/<int:cantidad>')
def actualizar_cantidad(producto_id, cantidad):
    """Actualiza la cantidad de un producto en el carrito"""
    carrito = obtener_carrito()
    
    if cantidad <= 0:
        return redirect(url_for('eliminar_del_carrito', producto_id=producto_id))
    
    for item in carrito:
        if item['id'] == producto_id:
            item['cantidad'] = cantidad
            break
    
    session.modified = True
    flash('Cantidad actualizada', 'success')
    return redirect(url_for('ver_carrito'))


@app.route('/limpiar-carrito')
def limpiar_carrito():
    """Limpia todo el carrito"""
    session['carrito'] = []
    session.modified = True
    flash('Carrito limpiado', 'success')
    return redirect(url_for('ver_carrito'))


@app.route('/checkout', methods=['GET', 'POST'])
def checkout():
    """Procesa el checkout"""
    if request.method == 'POST':
        nombre = request.form.get('nombre')
        email = request.form.get('email')
        direccion = request.form.get('direccion')
        
        if not all([nombre, email, direccion]):
            flash('Por favor completa todos los campos', 'error')
            return redirect(url_for('checkout'))
        
        carrito = obtener_carrito()
        if not carrito:
            flash('El carrito está vacío', 'error')
            return redirect(url_for('ver_carrito'))
        
        # Simular procesamiento del pedido
        session['carrito'] = []
        session.modified = True
        
        return render_template('confirmacion.html',nombre=nombre,email=email,direccion=direccion)
    
    carrito = obtener_carrito()
    if not carrito:
        flash('El carrito está vacío', 'info')
        return redirect(url_for('ver_carrito'))
    
    return render_template('checkout.html')


if __name__ == '__main__':
    app.run(debug=True)