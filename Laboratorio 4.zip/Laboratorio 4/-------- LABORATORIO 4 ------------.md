\-------- LABORATORIO 4 ---------------- EMERGENTES II -------------------   FECHA DE ENTREGA : 14/04/2026 



**SUBIR EN REPOSITORIO GIT** 



1\. Desarrollar un aplicación para simular un carrito de compras que almacene productos 



2\. Desarrollar un aplicación para simular un carrito de compras que almacene productos, precio, cantidad y totales



3\. Desarrollar un aplicación para simular un CRUD de una tabla contactos(ID, Nombre, Correo, Celular) 

